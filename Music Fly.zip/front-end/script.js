document.addEventListener("DOMContentLoaded", function() {
    const audioPlayer = document.getElementById("audio-player");
    const playlist = document.getElementById("playlist");

    const songs = [
        { title: "Let's Go 4", source: "/back-end/LET_S GO 4 - DJ GBR_ IG_ Ryan SP_ PH_ Davi_ Luki_ Don Juan_ Kadu _GH do 7_ GP_ TrapLaudo(MP3_160K).mp3" },
        { title: "Coração De Gelo", source: "/back-end/WIU - Coração de Gelo(MP3_160K).mp3" },
        { title: "Melhor som de one piece", source: "/back-end/Melhor Som de One Piece - Luffy (One Piece) _ Vitch Feat. _Geedix (Prod_ _LairtonTeclas)(MP3_160K).mp3" }
    ];

    songs.forEach((song, index) => {
        const listItem = document.createElement("li");
        listItem.textContent = song.title;
        listItem.addEventListener("click", () => {
            audioPlayer.src = song.source;
            audioPlayer.play();
        });
        playlist.appendChild(listItem);
    });
});
